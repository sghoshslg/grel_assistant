function init() {
  ClientSideResourceManager.addPaths("project/scripts", module, ["scripts/grel-assistant.js"]);
  ClientSideResourceManager.addPaths("project/styles", module, ["styles/grel-assistant.css"]);
}