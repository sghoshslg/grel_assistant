(function(){
  // Ready helper
  const onReady = (fn) => (document.readyState === "loading") ? document.addEventListener("DOMContentLoaded", fn) : fn();

  onReady(() => {
    window.grelAssistantLoaded = true;
    // badge
    const badge = document.createElement('div');
    badge.className = 'grel-badge';
    badge.textContent = 'GREL Assistant v3.2 loaded';
    document.body.appendChild(badge);

    // floating button (always visible to avoid header injection issues)
    const floating = document.createElement('button');
    floating.className = 'grel-floating';
    floating.textContent = 'GREL Helper';
    document.body.appendChild(floating);

    // modal
    const modal = document.createElement('div');
    modal.className = 'grel-helper-modal';
    modal.innerHTML = `
      <div class="grel-helper-card">
        <div class="gh-flex" style="justify-content:space-between">
          <h3 style="margin:0">GREL Helper</h3>
          <button type="button" class="gh-close">✕</button>
        </div>
        <div class="grel-helper-row gh-top">
          <label for="gh-search">Search</label>
          <input id="gh-search" type="search" placeholder="Filter templates (e.g., date, regex, title)"/>
        </div>
        <div class="grel-helper-row">
          <label for="gh-op">Template</label>
          <select id="gh-op" size="12" style="height:14em">
            <optgroup label="Basics">
              <option value="lower">Lowercase</option>
              <option value="upper">Uppercase</option>
              <option value="trim">Trim</option>
              <option value="replace">Replace (simple)</option>
              <option value="regex">Replace (regex)</option>
            </optgroup>
            <optgroup label="Text Formatting">
              <option value="titlecase">Title Case</option>
              <option value="capfirst">Capitalize First Word</option>
              <option value="prefix">Add prefix</option>
              <option value="suffix">Add suffix</option>
            </optgroup>
            <optgroup label="Cleaning">
              <option value="collapseSpaces">Collapse Whitespace</option>
              <option value="removePunct">Remove Punctuation</option>
              <option value="lettersNumbersOnly">Keep Only Letters/Numbers</option>
              <option value="stripHTML">Strip HTML Tags</option>
              <option value="normalize">Normalize Unicode</option>
            </optgroup>
            <optgroup label="Array / Split">
              <option value="split">Split to array</option>
              <option value="join">Join array</option>
              <option value="splitWordsTitlecase">Split Words → Titlecase Join</option>
            </optgroup>
            <optgroup label="Date/Time">
              <option value="dateparse">Parse date</option>
              <option value="isoDate">Convert to ISO Date</option>
              <option value="yearOnly">Extract Year Only</option>
            </optgroup>
            <optgroup label="Logic">
              <option value="ifBlankNull">If Blank → Null</option>
              <option value="ifContains">If Contains (substring)</option>
              <option value="ifelse">If / else (custom)</option>
              <option value="with">with() block</option>
              <option value="forEach">forEach() over array</option>
            </optgroup>
            <optgroup label="Special">
              <option value="number">To number</option>
              <option value="firstNumber">Extract First Number</option>
              <option value="domainFromURL">Extract Domain from URL</option>
              <option value="custom">Custom template</option>
            </optgroup>
          </select>
        </div>
        <div class="grel-helper-row gh-params"></div>
        <div class="grel-helper-preview gh-preview">value</div>
        <div class="grel-helper-actions">
          <button type="button" class="gh-insert">Insert</button>
          <button type="button" class="gh-close">Close</button>
        </div>
      </div>`;
    document.body.appendChild(modal);

    const params = modal.querySelector('.gh-params');
    const preview = modal.querySelector('.gh-preview');
    const opSel = modal.querySelector('#gh-op');
    const search = modal.querySelector('#gh-search');

    const templates = {
      lower: () => `value.toLowercase()`,
      upper: () => `value.toUppercase()`,
      trim: () => `value.trim()`,
      replace: (f,t) => `value.replace(${JSON.stringify(f)}, ${JSON.stringify(t)})`,
      regex: (f,t,flags) => `value.replace(/${f}/${flags||''}, ${JSON.stringify(t)})`,
      split: (sep) => `value.split(${JSON.stringify(sep||',')})`,
      join: (sep) => `value.join(${JSON.stringify(sep||', ')})`,
      prefix: (p) => `${JSON.stringify(p||'')} + value`,
      suffix: (s) => `value + ${JSON.stringify(s||'')}`,
      number: () => `value.toNumber()`,
      dateparse: (fmt) => `toDate(value, ${fmt ? JSON.stringify(fmt) : '"yyyy-MM-dd"'})`,
      ifelse: (cond, thenV, elseV) => `if(${cond||'value.length()>0'}, ${thenV||'value'}, ${elseV||'null'})`,
      with: (vname, expr) => `with(value, ${vname||'v'}, ${expr||'v'})`,
      forEach: (vname, body) => `forEach(value, ${vname||'v'}, ${body||'v'})`,
      custom: (tmpl) => tmpl || 'value',
      titlecase: () => `value.toTitlecase()`,
      capfirst: () => `if(value.length()>0, value.substring(0,1).toUppercase()+value.substring(1), value)`,
      normalize: () => `value.unicodeNormalize("NFD").replace(/[\\u0300-\\u036f]/, "")`,
      collapseSpaces: () => `value.replace(/\\s+/, " ").trim()`,
      removePunct: () => `value.replace(/[^\\w\\s]/, "")`,
      lettersNumbersOnly: () => `value.replace(/[^A-Za-z0-9\\s]/, "")`,
      stripHTML: () => `value.replace(/<[^>]*>/, "")`,
      isoDate: () => `value.toDate().toString("yyyy-MM-dd")`,
      yearOnly: () => `value.toDate().toString("yyyy")`,
      ifBlankNull: () => `if(isBlank(value), null, value)`,
      ifContains: (sub, thenV, elseV) => `if(value.contains(${JSON.stringify(sub||'keyword')}), ${thenV||'true'}, ${elseV||'false'})`,
      firstNumber: () => `value.match(/\\d+/)[0]`,
      domainFromURL: () => `value.parseUrl().host`,
      splitWordsTitlecase: () => `value.split(" ").forEach(v, v.toTitlecase()).join(" ")`
    };

    function renderParams(){
      params.innerHTML='';
      const op = opSel.value;
      const add = (label,id,type='text',ph='') => {
        const row = document.createElement('div');
        row.className='grel-helper-row';
        row.innerHTML = `${'<label>'+label+'</label>'}${type==='textarea'
          ? `<textarea id="${id}" rows="2" placeholder="${ph}"></textarea>`
          : `<input id="${id}" type="${type}" placeholder="${ph}">`}`;
        params.appendChild(row);
        return row.querySelector('#'+id);
      };
      let inputs=[];
      if (op==='replace') inputs=[add('Find','gh-find'),add('Replace with','gh-rep')];
      else if (op==='regex') inputs=[add('Regex','gh-regex','text','\\\\s+'),add('Replace with','gh-rep'),add('Flags','gh-flags','text','g,i,m')];
      else if (op==='split') inputs=[add('Separator','gh-sep','text',',')];
      else if (op==='join') inputs=[add('Separator','gh-sep','text',', ')];
      else if (op==='prefix') inputs=[add('Prefix','gh-p','text','Mr. ')];
      else if (op==='suffix') inputs=[add('Suffix','gh-s','text',' Ltd.')];
      else if (op==='dateparse') inputs=[add('Format','gh-fmt','text','yyyy-MM-dd')];
      else if (op==='ifelse') inputs=[add('Condition (GREL)','gh-cond','text','value.length()>0'),add('Then','gh-then','text','value'),add('Else','gh-else','text','null')];
      else if (op==='with') inputs=[add('Variable name','gh-vn','text','v'),add('Body (use variable)','gh-body','textarea','v.parseJson()')];
      else if (op==='forEach') inputs=[add('Variable name','gh-vn','text','v'),add('Body (use variable)','gh-body','textarea','v.trim()')];
      else if (op==='ifContains') inputs=[add('Substring','gh-sub','text','keyword'),add('Then','gh-then','text','true'),add('Else','gh-else','text','false')];
      else if (op==='custom') inputs=[add('Template (use \"value\")','gh-tmpl','textarea','with(value, v, v.trim().toTitlecase())')];

      const make = () => {
        try{
          const vals = inputs.map(n=>n.value||'');
          let s;
          switch(op){
            case 'replace': s=templates.replace(vals[0],vals[1]); break;
            case 'regex': s=templates.regex(vals[0],vals[1],vals[2]); break;
            case 'split': s=templates.split(vals[0]); break;
            case 'join': s=templates.join(vals[0]); break;
            case 'prefix': s=templates.prefix(vals[0]); break;
            case 'suffix': s=templates.suffix(vals[0]); break;
            case 'dateparse': s=templates.dateparse(vals[0]); break;
            case 'ifelse': s=templates.ifelse(vals[0],vals[1],vals[2]); break;
            case 'with': s=templates.with(vals[0],vals[1]); break;
            case 'forEach': s=templates.forEach(vals[0],vals[1]); break;
            case 'ifContains': s=templates.ifContains(vals[0],vals[1],vals[2]); break;
            case 'custom': s=templates.custom(vals[0]); break;
            default: s=templates[op]();
          }
          preview.textContent=s;
        }catch(e){ preview.textContent='/* error: '+e.message+' */'; }
      };
      inputs.forEach(n=>n.addEventListener('input',make));
      make();
    }
    opSel.addEventListener('change', renderParams);
    renderParams();

    // open/close
    floating.addEventListener('click', ()=>{ modal.style.display='flex'; search.focus(); });
    modal.querySelector('.gh-close').addEventListener('click', ()=> modal.style.display='none');

    // Insert into the most-recent expression editor
    function findEditor(){
      // Prefer any visible CodeMirror within dialogs; fallback to any textarea in dialogs
      const cms = Array.from(document.querySelectorAll('.dialog-container .CodeMirror'));
      if (cms.length) return cms[cms.length-1].CodeMirror;
      const ta = Array.from(document.querySelectorAll('.dialog-container textarea'));
      return ta.length ? ta[ta.length-1] : null;
    }
    modal.querySelector('.gh-insert').addEventListener('click', ()=>{
      const cm = findEditor();
      const text = preview.textContent;
      if (!cm) { alert('Open a transform dialog first to insert the GREL.'); return; }
      try{
        if (cm.getValue) {
          const doc = cm.getDoc();
          const sel = doc.getSelection();
          if (sel && sel.length>0) doc.replaceSelection(text);
          else doc.replaceRange(text, doc.getCursor());
        } else if (cm.tagName === 'TEXTAREA') {
          const start = cm.selectionStart, end = cm.selectionEnd;
          cm.value = cm.value.substring(0, start) + text + cm.value.substring(end);
        }
        modal.style.display='none';
      } catch(e){ alert('Could not insert: '+e.message); }
    });

  }); // onReady
})();